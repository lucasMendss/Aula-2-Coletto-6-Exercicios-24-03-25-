﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_2_Coletto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            void CalculaAreaRetangulo()
            {
                double baseRetangulo, alturaRetangulo, areaRetangulo;
                bool converteu = false;

                
                converteu = double.TryParse(Console.ReadLine(), out baseRetangulo);

                while (!converteu || baseRetangulo < 0 )
                {
                    Console.WriteLine("Valor inválido! Digite novamemnte");
                    converteu = double.TryParse(Console.ReadLine(), out baseRetangulo);
                }

                Console.WriteLine("Digite a medida da altura do retângulo: ");
                converteu = double.TryParse(Console.ReadLine(), out alturaRetangulo);

                while (!converteu || alturaRetangulo < 0)
                {
                    Console.WriteLine("Valor inválido! Digite novamemnte");
                    converteu = double.TryParse(Console.ReadLine(), out alturaRetangulo);
                }

                areaRetangulo = baseRetangulo * alturaRetangulo;

                Console.WriteLine("A área do retãngulo mede " + areaRetangulo + " uni.");

                Console.ReadKey();

            }

            void CalculaAreaECircunferencia ()
            {
                double diametro = 0, area, circunferencia;

                bool converteuDiametro = false; 

                while (!converteuDiametro)
                {
                    Console.WriteLine("Digite a medida do diâmetro do círculo: ");
                    converteuDiametro = double.TryParse(Console.ReadLine(), out diametro);

                    if(!converteuDiametro || diametro < 0)
                    {
                        Console.WriteLine("Valor inválido");
                        converteuDiametro = false;
                    }
                }

                area = Math.PI * Math.Sqrt((diametro / 2));
                circunferencia = diametro * Math.PI;

                Console.WriteLine("Valor da área do círculo: " + area.ToString("N2"));
                Console.WriteLine("Valor do perímetro do círculo: " + circunferencia.ToString("N2"));

                Console.ReadKey ();
            }

            CalculaAreaECircunferencia();
        }
    }
}
